//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var string = "01/12/2019"
let format = DateFormatter()
format.dateFormat = "mm/dd/yyyy"


var test = format.date(from: string)
print(test!)
